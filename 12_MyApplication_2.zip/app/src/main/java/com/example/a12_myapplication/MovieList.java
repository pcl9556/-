package com.example.a12_myapplication;

public class MovieList {
    MovieListResult boxOfficeResult;
}
