package com.example.a12_myapplication;

import java.util.ArrayList;

public class MovieListResult {
    String boxofficeType;
    String showRange;

    ArrayList<Movie> dailyBoxOfficeList = new ArrayList<Movie>();
}
