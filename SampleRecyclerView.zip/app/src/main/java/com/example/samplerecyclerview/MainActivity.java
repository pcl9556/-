package com.example.samplerecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);
        PersonAdepter adepter = new PersonAdepter();

        adepter.addItem(new Person("박채린","010-1234-1000"));
        adepter.addItem(new Person("김채린","010-1234-2000"));
        adepter.addItem(new Person("이채린","010-1234-3000"));
        adepter.addItem(new Person("한채린","010-1234-4000"));
        adepter.addItem(new Person("권채린","010-1234-5000"));
        adepter.addItem(new Person("강채린","010-1234-6000"));
        adepter.addItem(new Person("정채린","010-1234-7000"));

        recyclerView.setAdapter(adepter);
    }
}